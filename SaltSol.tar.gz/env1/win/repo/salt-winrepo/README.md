salt-winrepo
============

Salt Windows Software Package Manager Repo.

Documentation
-------------

Official Salt documentation provides a getting started guide.

http://docs.saltstack.com/en/latest/topics/windows/windows-package-manager.html
