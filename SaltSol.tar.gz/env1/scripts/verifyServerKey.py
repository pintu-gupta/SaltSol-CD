#!/usr/bin/python

from __future__ import print_function
from json import loads
from json import dumps

import fileinput
import os

servers="Windows-Minion,server1,server2,server3,Windows-Minion"
serverList = servers.split (",")

stdin_lines = [line for line in fileinput.input()]
ret = loads(''.join(stdin_lines))

addKey = 'salt-key -a list_item'

def checkServer(dictArg, keysListArg): 
  count = 0 
  key_not_found = 0

  for list_item in keysListArg:
    key_not_found = 0
    for key, values in dictArg.iteritems():
      if list_item in values:
        if key == 'minions_pre':
	  os.system(addKey)
        elif key == 'minions_denied':
	  print ("This ID %s is in use by other server. Please change the ID and add it again" % str(list_item))
        elif key == 'minions_rejected':
	  print ("This ID %s is rejected by Salt Master. Please contact Salt Administrator to add it again" % str(list_item))
        elif key == 'minions':
	  print ("This Server (ID %s) is already connected with Salt Master. No action taken." % str(list_item))
      else:
        key_not_found += 1

      if (key_not_found == 4):
        print ("Minion is not installed on Server (ID %s). Install Minion before adding it to Salt." % str(list_item))
        key_not_found = 0
  return count

checkServer(ret, serverList)
