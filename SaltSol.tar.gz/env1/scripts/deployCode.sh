#!/bin/bash

#List=$1
#releaseDeploy=$2
#Group=$3

AppList="app1"
EnvList="env1"
releaseDeploy="1.79"
Group="grp"

for AppName in $(echo $AppList | sed -n 1'p' | tr ',' '\n')
do
    for Env in $(echo $EnvList | sed -n 1'p' | tr ',' '\n')
    do
	NodeGroup=$Group"_"$AppName"_"$Env
        logger -p local7.info "$NodeGroup"
        logger -p local7.info "Executing salt -N $NodeGroup state.highstate saltenv=$AppName_$Env"
	salt -N "$NodeGroup" state.highstate --output=json saltenv=$NodeGroup
	if [ $? -eq 0 ]; then
	 	echo "Deployment completed successfully on $AppName. See the summary report for more details"
                logger -p local7.info "Execution Successful $AppName"
	else
		echo "Failed on $AppName"
                logger -p local7.info "Deployment failed on $AppName. See the summary report for more details."
	fi
        echo $Env
    done
done
