#!/bin/bash

#Task=$1
#Group=$1
#AppName=$2
#EnvName=$3
#ServerList=$4

tempdir=/srv/salt/temp

#ADD NEW ENVIRONMENT
#Install Minions
#Take Backup of current file and log information
#Add entry on /etc/salt/master.d/roots.conf
#Check if the SaltKey is available which can be accessed
#Approve Salt-keys
#Perform Test.ping and send report to group for validation
Task="AddNewEnv"
Group=grp
AppName=app3
EnvName=env10
ServerList=server1,server2,server3,server4,server5
#nodeGroupConfFile="/etc/salt/master.d/nodegroups.conf"
#appListFile="/etc/salt/master.d/applist.conf"
nodeGroupConfFile="/srv/salt/nodegroups.conf"
appListFile="/srv/salt/applist.conf"

salt-key -L --out=json | ./verifyServerKey.py

#Check if the nodeList is in ACC then no action needed, add the entries and print message Good to Go
#If the nodeList is in UN, accept the keys and proceed with other steps and print message Good to Go
#If they key is in denied state or reject state, exit workflow and print message that the key is in Reject state, please correct the issue.
#Delete .tmpfiles

while IFS= read -r envr
do
	if [[ $envr =~ $AppName"_"$EnvName ]]; then
			echo "Environmenrt exist...exiting"
			#Add Log entry "Environment exist"
		exit 0
	fi
done < "$appListFile"

echo "  "$AppName"_"$EnvName":" >> $appListFile
echo "    - /srv/salt/"$AppName"/"$EnvName >> $appListFile


while IFS= read -r nodegroups
do
	if [[ $nodegroups =~ "nodegroups" ]] 
	then
		echo "  "$Group"_"$AppName"_"$EnvName":" >> $nodeGroupConfFile
		for Server in $(echo $ServerList | sed -n 1'p' | tr ',' '\n')
		do
			echo "    - '"$Server"'" >> $nodeGroupConfFile
		done
		echo "" >> $nodeGroupConfFile
	fi
	break
done < "$nodeGroupConfFile"

mkdir /srv/salt/"$AppName"_"$EnvName"
#cd /srv/salt/"$AppName"_"$EnvName"
#cp /srv/salt/masterConfig/base.tar.gz .
#tar -xvzf base.tar.gz
#rm base.tar.gz 

#sudo pkill salt-master
#sudo salt-master -d
