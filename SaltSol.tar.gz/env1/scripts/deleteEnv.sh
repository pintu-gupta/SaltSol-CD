#!/bin/bash

#Group=$1
#AppName=$2
#EnvName=$3
#ServerList=$4
#MinionList=$5

Group=grp
AppName=app3
EnvName=env10
ServerList=server1,server2,server3,server4,server5
#nodeGroupConfFile="/etc/salt/master.d/nodegroups.conf"
#appListFile="/etc/salt/master.d/applist.conf"
nodeGroupConfFile="/srv/salt/nodegroups.conf"
appListFile="/srv/salt/applist.conf"

#salt-key -L --out=json | ./verifyServerKey.py
deleteEnv=$AppName"_"$EnvName
deleteFolder=$AppName"\/"$EnvName
grep -v $deleteEnv $appListFile > tmpF; mv tmpF $appListFile 
grep -v $deleteFolder $appListFile > tmpF; mv tmpF $appListFile
 
grep -v $deleteEnv $nodeGroupConfFile > tmpF; mv tmpF $nodeGroupConfFile 
for Server in $(echo $ServerList | sed -n 1'p' | tr ',' '\n')
do
	grep -v $Server $nodeGroupConfFile > tmpF; mv tmpF $nodeGroupConfFile 
done

