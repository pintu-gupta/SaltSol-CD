#!/usr/bin/python

from __future__ import print_function
from json import loads
from json import dumps

import fileinput

stdin_lines = [line for line in fileinput.input()]
ret = loads(''.join(stdin_lines))

for minion_id, data in ret.items():
    for key, value in ret[minion_id].items():
 #       if value['changes'] or value['result'] == False:
         print("Minion ID: %s  | \t" % str(minion_id), end="" )
         print("Result: %s\t" % str(value['result']), end="")
         print("Comments: %s" % str(value['comment']))
